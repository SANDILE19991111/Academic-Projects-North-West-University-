
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('booking-form');
  const name = document.getElementById('patient-name');
  const email = document.getElementById('patient-email');
  const date = document.getElementById('appointment-date');
  const time = document.getElementById('appointment-time');
  const reason = document.getElementById('visit-reason');
  const bookBtn = document.getElementById('book-appointment');

  const availability = {
    'Dr. Nhlayiseko': { monday: ['09:00', '10:00', '11:00'], friday: ['14:00', '15:00'] },
    'Dr. Tshembho': { monday: ['08:00', '09:00'], friday: ['10:00', '13:00'] },
    'Dr. Xihluke': { monday: ['11:00', '12:00'], friday: ['16:00', '17:00'] },
  };

  // Create doctor dropdown
  const doctorSelect = document.createElement('select');
  doctorSelect.id = 'doctor-select';
  doctorSelect.required = true;
  doctorSelect.innerHTML = `<option value="" disabled selected>Select a doctor</option>` +
    Object.keys(availability).map(d => `<option value="${d}">${d}</option>`).join('');
  email.parentElement.insertAdjacentHTML('afterend', `<label for="doctor-select">Select Doctor *</label>`);
  form.insertBefore(doctorSelect, email.nextElementSibling.nextElementSibling);

  // Set minimum date
  const today = new Date().toISOString().split('T')[0];
  date.setAttribute('min', today);

  // Update time slots when date or doctor is selected
  doctorSelect.addEventListener('change', updateTimes);
  date.addEventListener('input', updateTimes);

  function updateTimes() {
    const doctor = doctorSelect.value;
    const selected = new Date(date.value);
    const day = selected.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();

    // Check for weekends
    if (['saturday', 'sunday'].includes(day)) {
      return showMessage('Clinic is closed on weekends.', 'error');
    }

    const times = availability[doctor]?.[day] || [];
    const dropdown = document.createElement('select');
    dropdown.id = 'time-dropdown';
    dropdown.required = true;
    dropdown.innerHTML = `<option value="" disabled selected>Select a time</option>` +
      times.map(t => `<option value="${t}">${t}</option>`).join('');

    // Replace time input
    if (document.getElementById('time-dropdown')) {
      time.replaceWith(dropdown);
    } else {
      time.parentElement.replaceChild(dropdown, time);
    }
  }

  // Show feedback messages
  function showMessage(msg, type) {
    document.querySelector('.message')?.remove();
    const div = document.createElement('div');
    div.className = `message ${type}`;
    div.textContent = msg;
    form.insertBefore(div, bookBtn.parentElement);
    setTimeout(() => div.remove(), 5000);
  }

  // Validate form inputs
  function isValid() {
    const timeSelected = document.getElementById('time-dropdown')?.value;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!name.value.trim()) return showMessage('Enter your name', 'error'), false;
    if (!email.value.trim() || !emailPattern.test(email.value)) return showMessage('Enter a valid email', 'error'), false;
    if (!doctorSelect.value) return showMessage('Select a doctor', 'error'), false;
    if (!date.value) return showMessage('Select a date', 'error'), false;
    if (!timeSelected) return showMessage('Select a time slot', 'error'), false;
    return true;
  }

  // Handle booking
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!isValid()) return;

    const data = {
      name: name.value.trim(),
      email: email.value.trim(),
      doctor: doctorSelect.value,
      date: date.value,
      time: document.getElementById('time-dropdown').value,
      reason: reason.value.trim()
    };

    console.log('Submitting booking:', data);
    bookBtn.disabled = true;
    bookBtn.textContent = 'Booking...';

    setTimeout(() => {
      form.reset();
      doctorSelect.selectedIndex = 0;
      document.getElementById('time-dropdown')?.remove();
      bookBtn.disabled = false;
      bookBtn.textContent = 'Book Appointment';
      showMessage('Appointment booked successfully!', 'success');
      addToUpcoming(data);
    }, 1500);
  });

  // Add appointment to list
  function addToUpcoming(data) {
    const section = document.getElementById('upcoming-appointments');
    if (!section) return;

    const div = document.createElement('div');
    div.className = 'appointment-card';
    div.innerHTML = `
      <strong>${data.name}</strong> - ${data.doctor}<br>
      ${data.date} at ${data.time}<br>
      Reason: ${data.reason}
    `;
    section.appendChild(div);
  }
});
